<?php

$host = "localhost";
$user = "fastwork_activenumber";
$password = "Eynullafastwork2022";
$db = "fastwork_activenumber";
$uid = $_GET['uid'];
if ($uid) {
$sql = "select * from users WHERE uid = '$uid';";
$con = mysqli_connect($host,$user,$password,$db);

$result = mysqli_query($con,$sql);
$response = array();

while($row = mysqli_fetch_array($result)){
    array_push($response,array("deviceid"=>$row[2]));
}
if($response){
echo json_encode(array("users"=>$response));
} else {
    array_push($response,array("deviceid"=>'yoxdu'));
    echo json_encode(array("users"=>$response));
}
mysqli_close($con);
} else {
    echo 'error';
}
?>