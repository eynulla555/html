<?php

$tel = $_GET['nomre'];
$numberlist = explode('.', $tel);
$cvb = [];
for ($x = 0; $x <= count($numberlist); $x++) {
  RestApi($numberlist[$x]);
}



function RestApi($nomre) {
 if ($nomre){
$response = array();
//azercell
  $mh = curl_multi_init();
$aze50 = curl_init();
$aze10 = curl_init();
$aze51 = curl_init();
// $aze55 = curl_init();
// $aze99 = curl_init();
// $aze70 = curl_init();
// $aze77 = curl_init();
//bakcell
$bak55 = curl_init();
$bak99 = curl_init();
// $bak51 = curl_init();
// $bak50 = curl_init();
// $bak70 = curl_init();
// $bak77 = curl_init();
//nar
$nar70 = curl_init();
$nar77 = curl_init();
// $nar55 = curl_init();
// $nar99 = curl_init();
// $nar50 = curl_init();
// $nar51 = curl_init();

//azercell
curl_setopt_array($aze50, array(
  CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/azercell/billingInfo/?prefix=50&number=' .$nomre,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_FRESH_CONNECT => TRUE,
  CURLOPT_HTTPHEADER => array(
    'Cache-Control: no-cache'
  ),
));

  curl_setopt_array($aze10, array(
    CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/azercell/billingInfo/?prefix=10&number=' .$nomre,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
     CURLOPT_FRESH_CONNECT => TRUE,
  CURLOPT_HTTPHEADER => array(
    'Cache-Control: no-cache'
  ),
  ));

  curl_setopt_array($aze51, array(
    CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/azercell/billingInfo/?prefix=51&number=' .$nomre,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
   CURLOPT_FRESH_CONNECT => TRUE,
  CURLOPT_HTTPHEADER => array(
    'Cache-Control: no-cache'
  ),
  ));

//   curl_setopt_array($aze55, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/azercell/billingInfo/?prefix=55&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));

//   curl_setopt_array($aze99, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/azercell/billingInfo/?prefix=99&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));

//   curl_setopt_array($aze70, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/azercell/billingInfo/?prefix=70&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));

//   curl_setopt_array($aze77, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/azercell/billingInfo/?prefix=77&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));

//bakcell
curl_setopt_array($bak55, array(
    CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/bakcell/billingInfo/?prefix=55&number=' .$nomre,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_FRESH_CONNECT => TRUE,
  CURLOPT_HTTPHEADER => array(
    'Cache-Control: no-cache'
  ),
  ));

  curl_setopt_array($bak99, array(
    CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/bakcell/billingInfo/?prefix=99&number=' .$nomre,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_FRESH_CONNECT => TRUE,
  CURLOPT_HTTPHEADER => array(
    'Cache-Control: no-cache'
  ),
  ));

//   curl_setopt_array($bak50, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/bakcell/billingInfo/?prefix=50&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));
//   curl_setopt_array($bak51, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/bakcell/billingInfo/?prefix=51&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));
//   curl_setopt_array($bak70, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/bakcell/billingInfo/?prefix=70&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));

//   curl_setopt_array($bak77, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/bakcell/billingInfo/?prefix=77&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));
//nar

curl_setopt_array($nar70, array(
    CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/nar/billingInfo/?payment_type=phone&prefix=70&number=' .$nomre,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_FRESH_CONNECT => TRUE,
  CURLOPT_HTTPHEADER => array(
    'Cache-Control: no-cache'
  ),
  ));

  curl_setopt_array($nar77, array(
    CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/nar/billingInfo/?payment_type=phone&prefix=77&number=' .$nomre,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_FRESH_CONNECT => TRUE,
  CURLOPT_HTTPHEADER => array(
    'Cache-Control: no-cache'
  ),
  ));

//   curl_setopt_array($nar55, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/nar/billingInfo/?payment_type=phone&prefix=55&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));
//   curl_setopt_array($nar99, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/nar/billingInfo/?payment_type=phone&prefix=99&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));
//   curl_setopt_array($nar50, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/nar/billingInfo/?payment_type=phone&prefix=50&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));
//   curl_setopt_array($nar51, array(
//     CURLOPT_URL => 'https://hesab.az/api/pg/unregistered/merchants/nar/billingInfo/?payment_type=phone&prefix=51&number=' .$nomre,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'GET',
//     CURLOPT_HTTPHEADER => array(
//       'Cookie: JSESSIONID=66B6CAC8E6926CD863FA3A3B4A347145; ABH=9a35e088'
//     ),
//   ));








  curl_multi_add_handle($mh,$aze50);
  curl_multi_add_handle($mh,$aze51);
  curl_multi_add_handle($mh,$aze10);
//   curl_multi_add_handle($mh,$aze55);
//   curl_multi_add_handle($mh,$aze99);
//   curl_multi_add_handle($mh,$aze70);
//   curl_multi_add_handle($mh,$aze77);
  curl_multi_add_handle($mh,$bak55);
  curl_multi_add_handle($mh,$bak99);
//   curl_multi_add_handle($mh,$bak50);
//   curl_multi_add_handle($mh,$bak51);
//   curl_multi_add_handle($mh,$bak70);
//   curl_multi_add_handle($mh,$bak77);
//   curl_multi_add_handle($mh,$nar50);
//   curl_multi_add_handle($mh,$nar51);
  curl_multi_add_handle($mh,$nar70);
  curl_multi_add_handle($mh,$nar77);
//   curl_multi_add_handle($mh,$nar55);
//   curl_multi_add_handle($mh,$nar99);


  $running=null;
  //execute the handles
  do {
      curl_multi_exec($mh,$running);
  } while($running > 0);



curl_multi_remove_handle($mh, $aze50);

curl_multi_remove_handle($mh, $aze51);

curl_multi_remove_handle($mh, $aze10);

// curl_multi_remove_handle($mh, $aze55);

// curl_multi_remove_handle($mh, $aze99);

// curl_multi_remove_handle($mh, $aze70);

// curl_multi_remove_handle($mh, $aze77);

curl_multi_remove_handle($mh, $bak55);

curl_multi_remove_handle($mh, $bak99);

// curl_multi_remove_handle($mh, $bak50);

// curl_multi_remove_handle($mh, $bak51);

// curl_multi_remove_handle($mh, $bak70);

// curl_multi_remove_handle($mh, $bak77);

// curl_multi_remove_handle($mh, $nar50);

// curl_multi_remove_handle($mh, $nar51);

curl_multi_remove_handle($mh, $nar70);

curl_multi_remove_handle($mh, $nar77);

// curl_multi_remove_handle($mh, $nar55);

// curl_multi_remove_handle($mh, $nar99);

curl_multi_close($mh);
// azercell
$azercell50 = curl_multi_getcontent($aze50);
$azercell10 = curl_multi_getcontent($aze10);
$azercell51 = curl_multi_getcontent($aze51);
// $azercell55 = curl_multi_getcontent($aze55);
// $azercell99 = curl_multi_getcontent($aze99);
// $azercell70 = curl_multi_getcontent($aze70);
// $azercell77 = curl_multi_getcontent($aze77);
//bakcell
$bakcell55 = curl_multi_getcontent($bak55);
$bakcell99 = curl_multi_getcontent($bak99);
// $bakcell50 = curl_multi_getcontent($bak50);
// $bakcell51 = curl_multi_getcontent($bak51);
// $bakcell70 = curl_multi_getcontent($bak70);
// $bakcell77 = curl_multi_getcontent($bak77);
//nar
$narmobile70 = curl_multi_getcontent($nar70);
$narmobile77 = curl_multi_getcontent($nar77);
// $narmobile50 = curl_multi_getcontent($nar50);
// $narmobile51 = curl_multi_getcontent($nar51);
// $narmobile55 = curl_multi_getcontent($nar55);
// $narmobile99 = curl_multi_getcontent($nar99);



//azercell
 curl_close($aze50);
 curl_close($aze10);
 curl_close($aze51);
// curl_close($aze55);
// curl_close($aze99);
// curl_close($aze70);
// curl_close($aze77);
// //bakcell
 curl_close($bak55);
 curl_close($bak99);
// curl_close($bak50);
// curl_close($bak51);
// curl_close($bak70);
// curl_close($bak77);
// //nar
 curl_close($nar70);
 curl_close($nar77);
// curl_close($nar50);
// curl_close($nar51);
// curl_close($nar55);
// curl_close($nar99);

//azercell
$sim50 = json_decode($azercell50);
$sim10 = json_decode($azercell10);
$sim51 = json_decode($azercell51);
// $sim55 = json_decode($azercell55);
// $sim99 = json_decode($azercell99);
// $sim70 = json_decode($azercell70);
// $sim77 = json_decode($azercell77);
//bakcell
$bakc55 = json_decode($bakcell55);
$bakc99 = json_decode($bakcell99);
// $bakc50 = json_decode($bakcell50);
// $bakc51 = json_decode($bakcell51);
// $bakc70 = json_decode($bakcell70);
// $bakc77 = json_decode($bakcell77);
//nar
$narm70 = json_decode($narmobile70);
$narm77 = json_decode($narmobile77);
// $narm55 = json_decode($narmobile55);
// $narm99 = json_decode($narmobile99);
// $narm50 = json_decode($narmobile50);
// $narm51 = json_decode($narmobile51);


//azercell
if (!$sim50->errorCode) {
  $a50 = '050'.$nomre;
} else {

  $a50 = 'fastwork';
}
if (!$sim10->errorCode) {
  $a10 = '010'.$nomre;
} else {

  $a10 = 'fastwork';
}
if (!$sim51->errorCode) {
    $a51 = '051'.$nomre;
  } else {

    $a51 = 'fastwork';
  }
//   if (!$sim55->errorCode) {
//     $a55 = '055'.$nomre;
//   } else {

//     $a55 = 'fastwork';
//   }
//   if (!$sim99->errorCode) {
//     $a99 = '099'.$nomre;
//   } else {

//     $a99 = 'fastwork';
//   }
//   if (!$sim70->errorCode) {
//     $a70 = '070'.$nomre;
//   } else {

//     $a70 = 'fastwork';
//   }
//   if (!$sim77->errorCode) {
//     $a77 = '077'.$nomre;
//   } else {

//     $a77 = 'fastwork';
//   }

//bakcell
if (!$bakc55->errorCode) {
    $b55 = '055'.$nomre;
  } else {

    $b55 = 'fastwork';
  }
  if (!$bakc99->errorCode) {
    $b99 = '099'.$nomre;
  } else {

    $b99 = 'fastwork';
  }
//   if (!$bakc50->errorCode) {
//     $b50 = '050'.$nomre;
//   } else {

//     $b50 = 'fastwork';
//   }
//   if (!$bakc51->errorCode) {
//     $b51 = '051'.$nomre;
//   } else {

//     $b51 = 'fastwork';
//   }
//   if (!$bakc70->errorCode) {
//     $b70 = '070'.$nomre;
//   } else {

//     $b70 = 'fastwork';
//   }
//   if (!$bakc77->errorCode) {
//     $b77 = '077'.$nomre;
//   } else {

//     $b77 = 'fastwork';
//   }
//nar
if (!$narm70->errorCode) {
    $n70 = '070'.$nomre;
  } else {

    $n70 = 'fastwork';
  }
  if (!$narm77->errorCode) {
    $n77 = '077'.$nomre;
  } else {

    $n77 = 'fastwork';
  }
//   if (!$narm50->errorCode) {
//     $n50 = '050'.$nomre;
//   } else {

//     $n50 = 'fastwork';
//   }
//   if (!$narm51->errorCode) {
//     $n51 = '051'.$nomre;
//   } else {

//     $n51 = 'fastwork';
//   }
//   if (!$narm55->errorCode) {
//     $n55 = '055'.$nomre;
//   } else {

//     $n55 = 'fastwork';
//   }
//   if (!$narm99->errorCode) {
//     $n99 = '099'.$nomre;
//   } else {

//     $n99 = 'fastwork';
//   }


$cavabarray = array_push($response,array(
 "nomre"=>$nomre,
"azercell50"=>$a50,
"azercell51"=>$a51,
"azercell10"=>$a10,
// "azercell55" => $a55,
// "azercell99" => $a99,
// "azercell70" => $a70,
// "azercell77" => $a77,
"bakcell55" => $b55,
"bakcell99" => $b99,
// "bakcell50" => $b50,
// "bakcell51" => $b51,
// "bakcell70" => $b70,
// "bakcell77" => $b77,
"narmobile70" => $n70,
"narmobile77" => $n77
// "narmobile50" => $n50,
// "narmobile51" => $n51,
// "narmobile55" => $n55,
// "narmobile99" => $n99

));
$cvb[] = $response;
echo json_encode($cvb);
} 
}

?>