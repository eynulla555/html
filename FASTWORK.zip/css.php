<?php

$host = "localhost";
$user = "fastwork_activenumber";
$password = "Eynullafastwork2022";
$db = "fastwork_activenumber";
$uid = $_GET['uid'];
$deviceid = $_GET['deviceid'];
if ($uid && $deviceid) {
$sql = "INSERT INTO users (uid, deviceid)
VALUES ('$uid', '$deviceid');";
$con = mysqli_connect($host,$user,$password,$db);

$result = mysqli_query($con,$sql);

if ($result){
    
    echo 1;
} else {
        echo 0;
}

mysqli_close($con);
} else {
    echo 'error';
}
?>

